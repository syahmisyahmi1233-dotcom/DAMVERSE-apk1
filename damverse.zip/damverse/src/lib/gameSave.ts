import { supabase } from './supabase';
import { GameSaveData, DamType } from '../types/game';

const LOCAL_SAVE_PREFIX = 'damverse_slot_';

export class SaveManager {
  public static getDefaultSave(regionId = 'temenggor_perak', damType: DamType = 'concrete_gravity'): GameSaveData {
    return {
      slotNumber: 1,
      saveName: 'Initial Diversion & Survey',
      regionId,
      damType,
      constructionStage: 1,
      reservoir: {
        waterLevelM: 115.0,
        maxLevelM: 160.0,
        crestLevelM: 155.0,
        minOperatingLevelM: 110.0,
        tailwaterLevelM: 35.0,
        currentVolumeMCM: 1850,
        maxVolumeMCM: 6050,
        inflowCms: 135.0,
        spillwayGatePercent: 0,
        spillwayDischargeCms: 0,
        environmentalFlowCms: 25.0,
        totalOutflowCms: 25.0,
        weather: 'clear',
        floodAlarm: false,
        netStorageRateCms: 110.0,
      },
      turbines: [
        {
          id: 1,
          name: 'Francis Unit 1',
          active: true,
          flowCms: 45,
          maxFlowCms: 75,
          outputMW: 87,
          ratedCapacityMW: 100,
          efficiency: 0.93,
          bearingTempC: 52,
          vibrationMmS: 1.4,
          wicketGatePercent: 60,
        },
        {
          id: 2,
          name: 'Francis Unit 2',
          active: true,
          flowCms: 45,
          maxFlowCms: 75,
          outputMW: 87,
          ratedCapacityMW: 100,
          efficiency: 0.93,
          bearingTempC: 54,
          vibrationMmS: 1.5,
          wicketGatePercent: 60,
        },
        {
          id: 3,
          name: 'Francis Unit 3',
          active: false,
          flowCms: 0,
          maxFlowCms: 75,
          outputMW: 0,
          ratedCapacityMW: 100,
          efficiency: 0.93,
          bearingTempC: 32,
          vibrationMmS: 0.1,
          wicketGatePercent: 0,
        },
        {
          id: 4,
          name: 'Francis Unit 4',
          active: false,
          flowCms: 0,
          maxFlowCms: 75,
          outputMW: 0,
          ratedCapacityMW: 100,
          efficiency: 0.93,
          bearingTempC: 31,
          vibrationMmS: 0.1,
          wicketGatePercent: 0,
        },
      ],
      finances: {
        fundsRM: 35000000,
        totalRevenueRM: 450000,
        tariffPerKWhRM: 0.38,
        operatingExpensesPerHourRM: 4200,
        netRevenueRateRMPerHour: 62000,
      },
      township: {
        housesCount: 24,
        industrialParksCount: 2,
        substationLevel: 2,
        solarFarmPanels: 80,
        batteryStorageMWh: 15,
        waterTreatmentPlant: true,
        fishLadder: false,
        floodProtectionDyke: true,
        scadaAutomatedGates: false,
      },
      missions: [
        {
          id: 'm_diversion_safe',
          title: 'River Diversion Stability',
          objective: 'Maintain downstream eco-flow above 25 m³/s while inspecting the diversion tunnel.',
          rewardRM: 1500000,
          isCompleted: false,
          progressPercent: 65,
          category: 'hydrology',
        },
        {
          id: 'm_powerhouse_online',
          title: 'Grid Frequency Synchronization',
          objective: 'Synchronize 2 Francis turbines to generate at least 150 MW at 50 Hz.',
          rewardRM: 3000000,
          isCompleted: false,
          progressPercent: 85,
          category: 'energy',
        },
        {
          id: 'm_concrete_monolith',
          title: 'Dam Crest Roadway Construction',
          objective: 'Advance dam construction to Stage 4 to open the crest service road for 4x4 vehicles.',
          rewardRM: 4500000,
          isCompleted: false,
          progressPercent: 40,
          category: 'construction',
        },
      ],
      playerPos: { x: 0, y: 142, z: 12, inVehicle: false },
      gameTimeHours: 10.5,
      updatedAt: new Date().toISOString(),
    };
  }

  public static async saveGame(saveData: GameSaveData, userId?: string): Promise<{ success: boolean; cloud: boolean; error?: string }> {
    saveData.updatedAt = new Date().toISOString();

    // 1. Always save locally immediately
    const key = `${LOCAL_SAVE_PREFIX}${saveData.slotNumber}`;
    try {
      localStorage.setItem(key, JSON.stringify(saveData));
    } catch {
      // Local storage full
    }

    // 2. If authenticated with Supabase, sync to cloud
    if (userId && !userId.startsWith('guest_')) {
      try {
        const { error } = await supabase.from('game_saves').upsert({
          user_id: userId,
          slot_number: saveData.slotNumber,
          save_name: saveData.saveName,
          region_id: saveData.regionId,
          construction_stage: saveData.constructionStage,
          finances: saveData.finances,
          reservoir: saveData.reservoir,
          turbines: saveData.turbines,
          upgrades: saveData.township,
          missions: saveData.missions,
          player_pos: saveData.playerPos,
          updated_at: saveData.updatedAt,
        }, {
          onConflict: 'user_id,slot_number',
        });

        if (!error) {
          return { success: true, cloud: true };
        }
      } catch (err: unknown) {
        console.warn('Cloud save failed, local save persisted:', err);
      }
    }

    return { success: true, cloud: false };
  }

  public static async loadGame(slotNumber = 1, userId?: string): Promise<GameSaveData | null> {
    // 1. Try to load from Supabase cloud if user is logged in
    if (userId && !userId.startsWith('guest_')) {
      try {
        const { data, error } = await supabase
          .from('game_saves')
          .select('*')
          .eq('user_id', userId)
          .eq('slot_number', slotNumber)
          .maybeSingle();

        if (!error && data) {
          const loaded: GameSaveData = {
            id: data.id,
            userId: data.user_id,
            slotNumber: data.slot_number,
            saveName: data.save_name,
            regionId: data.region_id,
            damType: (data.dam_type as DamType) || 'concrete_gravity',
            constructionStage: data.construction_stage || 1,
            reservoir: data.reservoir,
            turbines: data.turbines,
            finances: data.finances,
            township: data.upgrades || SaveManager.getDefaultSave().township,
            missions: data.missions || SaveManager.getDefaultSave().missions,
            playerPos: data.player_pos || { x: 0, y: 142, z: 12, inVehicle: false },
            gameTimeHours: 11.0,
            updatedAt: data.updated_at,
          };
          // Cache locally
          localStorage.setItem(`${LOCAL_SAVE_PREFIX}${slotNumber}`, JSON.stringify(loaded));
          return loaded;
        }
      } catch (err) {
        console.warn('Supabase cloud fetch failed, falling back to local storage:', err);
      }
    }

    // 2. Fallback to Local Storage
    const local = localStorage.getItem(`${LOCAL_SAVE_PREFIX}${slotNumber}`);
    if (local) {
      try {
        return JSON.parse(local);
      } catch {
        // Corrupted
      }
    }

    return null;
  }

  public static listLocalSlots(): Array<{ slot: number; name: string; date: string; stage: number }> {
    const list = [];
    for (let i = 1; i <= 3; i++) {
      const data = localStorage.getItem(`${LOCAL_SAVE_PREFIX}${i}`);
      if (data) {
        try {
          const parsed = JSON.parse(data) as GameSaveData;
          list.push({
            slot: i,
            name: parsed.saveName || `Save Slot ${i}`,
            date: new Date(parsed.updatedAt).toLocaleDateString(),
            stage: parsed.constructionStage,
          });
        } catch {
          // ignore
        }
      }
    }
    return list;
  }
}
