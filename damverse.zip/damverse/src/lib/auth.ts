import { supabase } from './supabase';
import { UserProfile } from '../types/game';

const GUEST_PROFILE_KEY = 'damverse_guest_profile';

export class AuthManager {
  private currentProfile: UserProfile | null = null;
  private listeners: Array<(profile: UserProfile | null) => void> = [];

  constructor() {
    this.initSession();
  }

  private async initSession() {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        this.currentProfile = {
          id: session.user.id,
          email: session.user.email,
          username: session.user.user_metadata?.username || session.user.email?.split('@')[0] || 'Engineer',
          isGuest: false,
          reputation: 100,
        };
      } else {
        // Check for existing guest profile
        const storedGuest = localStorage.getItem(GUEST_PROFILE_KEY);
        if (storedGuest) {
          this.currentProfile = JSON.parse(storedGuest);
        }
      }
    } catch {
      // Local fallback
      const storedGuest = localStorage.getItem(GUEST_PROFILE_KEY);
      if (storedGuest) {
        this.currentProfile = JSON.parse(storedGuest);
      }
    }
    this.notify();

    // Listen to Supabase auth state changes
    supabase.auth.onAuthStateChange(async (_event, session) => {
      if (session?.user) {
        this.currentProfile = {
          id: session.user.id,
          email: session.user.email,
          username: session.user.user_metadata?.username || session.user.email?.split('@')[0] || 'Chief Engineer',
          isGuest: false,
          reputation: 100,
        };
      } else if (!this.currentProfile?.isGuest) {
        this.currentProfile = null;
      }
      this.notify();
    });
  }

  public subscribe(callback: (profile: UserProfile | null) => void) {
    this.listeners.push(callback);
    callback(this.currentProfile);
    return () => {
      this.listeners = this.listeners.filter(cb => cb !== callback);
    };
  }

  private notify() {
    for (const cb of this.listeners) {
      cb(this.currentProfile);
    }
  }

  public getProfile(): UserProfile | null {
    return this.currentProfile;
  }

  public async signInWithEmail(email: string, pass: string): Promise<{ success: boolean; error?: string }> {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password: pass,
      });
      if (error) return { success: false, error: error.message };
      if (data.user) {
        this.currentProfile = {
          id: data.user.id,
          email: data.user.email,
          username: data.user.user_metadata?.username || email.split('@')[0],
          isGuest: false,
          reputation: 100,
        };
        this.notify();
        return { success: true };
      }
      return { success: false, error: 'Authentication failed' };
    } catch (err: unknown) {
      return { success: false, error: (err as Error).message || 'Network connection failed' };
    }
  }

  public async signUpWithEmail(email: string, pass: string, username: string): Promise<{ success: boolean; error?: string }> {
    try {
      const { data, error } = await supabase.auth.signUp({
        email: email.trim(),
        password: pass,
        options: {
          data: {
            username: username.trim(),
          },
        },
      });
      if (error) return { success: false, error: error.message };
      if (data.user) {
        this.currentProfile = {
          id: data.user.id,
          email: data.user.email,
          username: username.trim(),
          isGuest: false,
          reputation: 100,
        };
        this.notify();
        return { success: true };
      }
      return { success: true };
    } catch (err: unknown) {
      return { success: false, error: (err as Error).message || 'Signup failed' };
    }
  }

  public async resetPassword(email: string): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email.trim());
      if (error) return { success: false, error: error.message };
      return { success: true };
    } catch (err: unknown) {
      return { success: false, error: (err as Error).message || 'Reset failed' };
    }
  }

  public async signOut() {
    try {
      await supabase.auth.signOut();
    } catch {
      // ignore
    }
    this.currentProfile = null;
    localStorage.removeItem(GUEST_PROFILE_KEY);
    this.notify();
  }

  public startGuestMode(customName?: string): UserProfile {
    const guestId = 'guest_' + Math.random().toString(36).substring(2, 9);
    const profile: UserProfile = {
      id: guestId,
      username: customName || 'Contractor_' + guestId.slice(-4),
      isGuest: true,
      reputation: 100,
    };
    this.currentProfile = profile;
    localStorage.setItem(GUEST_PROFILE_KEY, JSON.stringify(profile));
    this.notify();
    return profile;
  }
}

export const authManager = new AuthManager();
