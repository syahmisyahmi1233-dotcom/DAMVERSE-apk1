import React from 'react';
import { X, Sliders, Volume2, Save, LogOut, CheckCircle2, Shield } from 'lucide-react';
import { GraphicsPreset, GameSettings, UserProfile } from '../types/game';
import { soundManager } from '../lib/audio';

interface SettingsModalProps {
  settings: GameSettings;
  user: UserProfile | null;
  onUpdatePreset: (preset: GraphicsPreset) => void;
  onUpdateVolume: (master: number, sfx: number, ambient: number) => void;
  onManualSave: () => void;
  isSaving: boolean;
  saveStatus: string | null;
  onExitToMenu: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  user,
  onUpdatePreset,
  onUpdateVolume,
  onManualSave,
  isSaving,
  saveStatus,
  onExitToMenu,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 z-50 select-none">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-lg rounded-2xl p-5 text-slate-100 shadow-2xl relative max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-200">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide">DAMVERSE SETTINGS & CLOUD</h2>
              <p className="text-xs text-slate-400">Graphics optimization for mobile & Supabase persistence</p>
            </div>
          </div>
          <button
            onClick={() => { soundManager.playClick(); onClose(); }}
            className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Graphics Presets */}
        <div className="mb-4">
          <label className="text-xs font-bold text-slate-300 block mb-2">GRAPHICS PRESET (AAA 3D ENGINE)</label>
          <div className="grid grid-cols-3 gap-2">
            {(['HIGH', 'BALANCED', 'PERFORMANCE'] as GraphicsPreset[]).map((preset) => (
              <button
                key={preset}
                onClick={() => {
                  soundManager.playClick();
                  onUpdatePreset(preset);
                }}
                className={`py-2 px-3 rounded-xl border text-xs font-bold flex flex-col items-center gap-0.5 transition-all ${
                  settings.graphicsPreset === preset
                    ? 'bg-cyan-600 text-white border-cyan-400 shadow-lg'
                    : 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-white'
                }`}
              >
                <span>{preset}</span>
                <span className="text-[9px] font-normal opacity-80">
                  {preset === 'HIGH' ? 'Soft Shadows, 1.5x DPR' : preset === 'BALANCED' ? 'Standard 1.0x DPR' : 'High FPS, 0.8x DPR'}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Audio Volume Controls */}
        <div className="mb-5 bg-slate-800/40 border border-slate-800 p-3.5 rounded-xl space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-300 mb-1">
            <Volume2 className="w-4 h-4 text-cyan-400" />
            <span>AUDIO LEVELS</span>
          </div>

          <div>
            <div className="flex justify-between text-[11px] text-slate-400 mb-1">
              <span>Master Volume</span>
              <span className="font-mono">{Math.round(settings.masterVolume * 100)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={settings.masterVolume}
              onChange={(e) => onUpdateVolume(Number(e.target.value), settings.sfxVolume, settings.ambientVolume)}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
            />
          </div>

          <div>
            <div className="flex justify-between text-[11px] text-slate-400 mb-1">
              <span>SFX & Machinery</span>
              <span className="font-mono">{Math.round(settings.sfxVolume * 100)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={settings.sfxVolume}
              onChange={(e) => onUpdateVolume(settings.masterVolume, Number(e.target.value), settings.ambientVolume)}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
            />
          </div>
        </div>

        {/* Supabase Cloud Save & Player Status */}
        <div className="mb-5 bg-slate-950/70 border border-slate-800 p-3.5 rounded-xl flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Shield className="w-5 h-5 text-emerald-400" />
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>{user?.username || 'Contractor'}</span>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-1.5 py-0.5 rounded border border-emerald-800">
                  {user?.isGuest ? 'GUEST (OFFLINE)' : 'SUPABASE CLOUD'}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                {user?.isGuest ? 'Auto-syncing to local device storage' : 'Continuous sync to Supabase game_saves'}
              </p>
            </div>
          </div>

          <button
            disabled={isSaving}
            onClick={() => {
              soundManager.playClick();
              onManualSave();
            }}
            className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-bold px-3 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow-lg active:scale-95 transition-all"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'SAVING...' : 'SAVE GAME'}</span>
          </button>
        </div>

        {saveStatus && (
          <div className="mb-4 text-xs font-bold text-emerald-400 flex items-center gap-1.5 justify-center bg-emerald-950/40 p-2 rounded-lg border border-emerald-800">
            <CheckCircle2 className="w-4 h-4" />
            <span>{saveStatus}</span>
          </div>
        )}

        {/* Return to Main Menu */}
        <div className="pt-2 border-t border-slate-800 flex justify-end">
          <button
            onClick={() => {
              soundManager.playClick();
              onExitToMenu();
            }}
            className="bg-slate-800 hover:bg-rose-900/60 text-slate-300 hover:text-rose-200 border border-slate-700 hover:border-rose-600 px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all active:scale-95"
          >
            <LogOut className="w-4 h-4" />
            <span>RETURN TO MAIN MENU</span>
          </button>
        </div>
      </div>
    </div>
  );
};
