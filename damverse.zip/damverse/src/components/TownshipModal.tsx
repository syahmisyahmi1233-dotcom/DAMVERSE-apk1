import React from 'react';
import { X, Building2, Sun, BatteryCharging, Droplets, CheckCircle2, ShieldCheck } from 'lucide-react';
import { TownshipInfrastructure } from '../types/game';
import { soundManager } from '../lib/audio';

interface TownshipModalProps {
  township: TownshipInfrastructure;
  fundsRM: number;
  onUpgrade: (field: keyof TownshipInfrastructure, cost: number) => void;
  onClose: () => void;
}

export const TownshipModal: React.FC<TownshipModalProps> = ({
  township,
  fundsRM,
  onUpgrade,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 z-50 select-none">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-2xl p-5 text-slate-100 shadow-2xl relative max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-950 border border-indigo-500/50 flex items-center justify-center text-indigo-400">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide">DOWNSTREAM TOWNSHIP & REGIONAL INFRASTRUCTURE</h2>
              <p className="text-xs text-slate-400">Expand local Malaysian communities, industrial corridors, and hybrid energy facilities</p>
            </div>
          </div>
          <button
            onClick={() => { soundManager.playClick(); onClose(); }}
            className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Upgrades Grid */}
        <div className="grid grid-cols-2 gap-3 mb-3">
          {/* 1. Staff Quarters & Kampung Houses */}
          <div className="bg-slate-800/80 border border-slate-700 p-3.5 rounded-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-indigo-300">Staff Quarters & Village</span>
                <span className="text-xs font-mono font-bold text-white bg-slate-900 px-2 py-0.5 rounded">{township.housesCount} Homes</span>
              </div>
              <p className="text-[11px] text-slate-300">Expands residential township for dam engineers, technicians, and local families.</p>
            </div>
            <button
              disabled={fundsRM < 850000}
              onClick={() => { soundManager.playClick(); onUpgrade('housesCount', 850000); }}
              className="mt-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-bold py-1.5 px-3 rounded-lg text-xs flex items-center justify-between shadow active:scale-95 transition-all"
            >
              <span>EXPAND (+6)</span>
              <span className="font-mono text-[11px]">RM 850K</span>
            </button>
          </div>

          {/* 2. Floating Solar Farm */}
          <div className="bg-slate-800/80 border border-slate-700 p-3.5 rounded-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-amber-300 flex items-center gap-1">
                  <Sun className="w-3.5 h-3.5" /> Floating Solar Array
                </span>
                <span className="text-xs font-mono font-bold text-white bg-slate-900 px-2 py-0.5 rounded">{township.solarFarmPanels} MW</span>
              </div>
              <p className="text-[11px] text-slate-300">Photovoltaic floating islands on the reservoir surface providing hybrid solar peak power.</p>
            </div>
            <button
              disabled={fundsRM < 2200000}
              onClick={() => { soundManager.playClick(); onUpgrade('solarFarmPanels', 2200000); }}
              className="mt-3 bg-amber-600 hover:bg-amber-500 disabled:opacity-40 text-white font-bold py-1.5 px-3 rounded-lg text-xs flex items-center justify-between shadow active:scale-95 transition-all"
            >
              <span>INSTALL (+25MW)</span>
              <span className="font-mono text-[11px]">RM 2.2M</span>
            </button>
          </div>

          {/* 3. Battery Energy Storage System (BESS) */}
          <div className="bg-slate-800/80 border border-slate-700 p-3.5 rounded-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-emerald-300 flex items-center gap-1">
                  <BatteryCharging className="w-3.5 h-3.5" /> BESS Storage
                </span>
                <span className="text-xs font-mono font-bold text-white bg-slate-900 px-2 py-0.5 rounded">{township.batteryStorageMWh} MWh</span>
              </div>
              <p className="text-[11px] text-slate-300">Grid stabilization battery racks absorbing frequency spikes and storing peak power.</p>
            </div>
            <button
              disabled={fundsRM < 3500000}
              onClick={() => { soundManager.playClick(); onUpgrade('batteryStorageMWh', 3500000); }}
              className="mt-3 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-bold py-1.5 px-3 rounded-lg text-xs flex items-center justify-between shadow active:scale-95 transition-all"
            >
              <span>ADD CAPACITY (+15MWh)</span>
              <span className="font-mono text-[11px]">RM 3.5M</span>
            </button>
          </div>

          {/* 4. Water Treatment Plant */}
          <div className="bg-slate-800/80 border border-slate-700 p-3.5 rounded-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-cyan-300 flex items-center gap-1">
                  <Droplets className="w-3.5 h-3.5" /> Water Treatment Plant
                </span>
                <span className="text-xs font-mono font-bold text-emerald-400">
                  {township.waterTreatmentPlant ? 'ACTIVE' : 'LOCKED'}
                </span>
              </div>
              <p className="text-[11px] text-slate-300">Pumps treated water from tailrace to supply state domestic potable water networks.</p>
            </div>
            {!township.waterTreatmentPlant ? (
              <button
                disabled={fundsRM < 4800000}
                onClick={() => { soundManager.playClick(); onUpgrade('waterTreatmentPlant', 4800000); }}
                className="mt-3 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-white font-bold py-1.5 px-3 rounded-lg text-xs flex items-center justify-between shadow active:scale-95 transition-all"
              >
                <span>COMMISSION PLANT</span>
                <span className="font-mono text-[11px]">RM 4.8M</span>
              </button>
            ) : (
              <div className="mt-3 bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-center py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> 120 MLD Potable Water Flow
              </div>
            )}
          </div>
        </div>

        {/* Eco Flow Protection */}
        <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span className="text-slate-300">Environmental Flow Requirement: 25.0 m³/s baseline guaranteed for river ecology.</span>
          </div>
          <span className="font-mono font-bold text-emerald-400">COMPLIANT</span>
        </div>
      </div>
    </div>
  );
};
