import React from 'react';
import { X, Sliders, AlertTriangle, Volume2, Droplets } from 'lucide-react';
import { ReservoirState } from '../types/game';
import { soundManager } from '../lib/audio';

interface SpillwayModalProps {
  reservoir: ReservoirState;
  onUpdateGates: (percent: number) => void;
  onClose: () => void;
}

export const SpillwayModal: React.FC<SpillwayModalProps> = ({
  reservoir,
  onUpdateGates,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 z-50 select-none">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-xl rounded-2xl p-5 text-slate-100 shadow-2xl relative">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-950 border border-cyan-500/50 flex items-center justify-center text-cyan-400">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide">SPILLWAY RADIAL GATES CONTROL</h2>
              <p className="text-xs text-slate-400">Ogee Crest & Flip-Bucket Hydraulic Discharge System</p>
            </div>
          </div>
          <button
            onClick={() => { soundManager.playClick(); onClose(); }}
            className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Discharge Metrics Grid */}
        <div className="grid grid-cols-3 gap-3 mb-5">
          <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
            <div className="text-[11px] text-slate-400">DISCHARGE RATE</div>
            <div className="text-lg font-bold font-mono text-cyan-300">
              {Math.round(reservoir.spillwayDischargeCms)} <span className="text-xs font-normal text-slate-400">m³/s</span>
            </div>
          </div>

          <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
            <div className="text-[11px] text-slate-400">HEAD OVER CREST</div>
            <div className="text-lg font-bold font-mono text-emerald-300">
              {Math.max(0, reservoir.waterLevelM - 138).toFixed(1)} <span className="text-xs font-normal text-slate-400">m</span>
            </div>
          </div>

          <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
            <div className="text-[11px] text-slate-400">CHUTE VELOCITY</div>
            <div className="text-lg font-bold font-mono text-amber-300">
              {(reservoir.spillwayGatePercent > 0 ? 28.5 + (reservoir.spillwayGatePercent / 100) * 12 : 0).toFixed(1)} <span className="text-xs font-normal text-slate-400">m/s</span>
            </div>
          </div>
        </div>

        {/* Gate Aperture Slider */}
        <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700 mb-5">
          <div className="flex justify-between items-center mb-2">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Droplets className="w-4 h-4 text-cyan-400" />
              <span>RADIAL TAINTER GATES OPENING</span>
            </label>
            <span className="text-sm font-mono font-extrabold text-cyan-400 bg-cyan-950/80 px-2.5 py-0.5 rounded border border-cyan-800">
              {reservoir.spillwayGatePercent}%
            </span>
          </div>

          <input
            type="range"
            min="0"
            max="100"
            step="5"
            value={reservoir.spillwayGatePercent}
            onChange={(e) => onUpdateGates(Number(e.target.value))}
            className="w-full h-3 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
          />

          <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
            <span>0% (Closed)</span>
            <span>25%</span>
            <span>50%</span>
            <span>75%</span>
            <span>100% (Full Chute)</span>
          </div>
        </div>

        {/* Safety Actions & Sirens */}
        <div className="flex items-center justify-between bg-slate-950/60 p-3 rounded-xl border border-slate-800">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Sound emergency siren before releasing above 300 m³/s to warn downstream settlements.</span>
          </div>

          <button
            onClick={() => soundManager.playSiren()}
            className="bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold px-3 py-2 rounded-xl text-xs flex items-center gap-1.5 shrink-0 shadow-lg active:scale-95 transition-all"
          >
            <Volume2 className="w-4 h-4" />
            TEST SIREN
          </button>
        </div>
      </div>
    </div>
  );
};
