import React from 'react';
import { X, Zap, Power, Activity, Thermometer } from 'lucide-react';
import { TurbineState, GridState } from '../types/game';
import { soundManager } from '../lib/audio';

interface TurbineModalProps {
  turbines: TurbineState[];
  grid: GridState;
  onToggleTurbine: (id: number) => void;
  onUpdateWicketGate: (id: number, percent: number) => void;
  onClose: () => void;
}

export const TurbineModal: React.FC<TurbineModalProps> = ({
  turbines,
  grid,
  onToggleTurbine,
  onUpdateWicketGate,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 z-50 select-none">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-2xl p-5 text-slate-100 shadow-2xl relative max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-950 border border-emerald-500/50 flex items-center justify-center text-emerald-400">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide">HYDRO POWERHOUSE GENERATOR CONTROL</h2>
              <p className="text-xs text-slate-400">4x Vertical-Shaft Francis Hydro Turbines (Total {Math.round(grid.totalGenerationMW)} MW)</p>
            </div>
          </div>
          <button
            onClick={() => { soundManager.playClick(); onClose(); }}
            className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 4 Turbine Cards */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          {turbines.map((t) => (
            <div
              key={t.id}
              className={`p-3.5 rounded-xl border transition-all ${
                t.active
                  ? 'bg-slate-800/90 border-emerald-500/50 shadow-md'
                  : 'bg-slate-900/60 border-slate-800 opacity-75'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className={`w-2.5 h-2.5 rounded-full ${t.active ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'}`} />
                  <span className="text-xs font-bold text-slate-200">{t.name}</span>
                </div>
                <button
                  onClick={() => {
                    soundManager.playClick();
                    onToggleTurbine(t.id);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all ${
                    t.active
                      ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                      : 'bg-slate-700 hover:bg-slate-600 text-slate-300'
                  }`}
                >
                  <Power className="w-3 h-3" />
                  {t.active ? 'ONLINE' : 'OFFLINE'}
                </button>
              </div>

              {/* Power & Flow metrics */}
              <div className="grid grid-cols-2 gap-2 mb-2 text-xs font-mono">
                <div className="bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">OUTPUT</span>
                  <span className="text-emerald-300 font-extrabold">{t.outputMW.toFixed(1)} MW</span>
                </div>
                <div className="bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">DISCHARGE</span>
                  <span className="text-cyan-300 font-extrabold">{t.flowCms.toFixed(0)} m³/s</span>
                </div>
              </div>

              {/* Telemetry row */}
              <div className="flex items-center justify-between text-[10px] text-slate-400 mb-2 font-mono px-1">
                <span className="flex items-center gap-1">
                  <Thermometer className="w-3 h-3 text-amber-400" />
                  {t.bearingTempC.toFixed(1)}°C
                </span>
                <span className="flex items-center gap-1">
                  <Activity className="w-3 h-3 text-cyan-400" />
                  {t.vibrationMmS.toFixed(1)} mm/s
                </span>
                <span>η {(t.efficiency * 100).toFixed(0)}%</span>
              </div>

              {/* Wicket Gate Slider */}
              <div>
                <div className="flex justify-between text-[10px] font-bold text-slate-400 mb-1">
                  <span>WICKET GATES</span>
                  <span className="text-emerald-400 font-mono">{t.wicketGatePercent}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  step="5"
                  disabled={!t.active}
                  value={t.wicketGatePercent}
                  onChange={(e) => onUpdateWicketGate(t.id, Number(e.target.value))}
                  className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-500 disabled:opacity-30"
                />
              </div>
            </div>
          ))}
        </div>

        {/* Grid Interconnection Summary */}
        <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
          <div className="text-xs">
            <span className="text-slate-400">National Grid Interconnection: </span>
            <span className={`font-bold font-mono ${grid.blackoutRisk ? 'text-red-400' : 'text-emerald-400'}`}>
              275kV / {grid.frequencyHz.toFixed(2)} Hz ({grid.stabilityIndex > 0.85 ? 'STABLE' : 'UNSTABLE'})
            </span>
          </div>

          <div className="text-xs font-mono font-bold text-amber-400">
            TOTAL: {Math.round(grid.totalGenerationMW)} MW / 400 MW MAX
          </div>
        </div>
      </div>
    </div>
  );
};
