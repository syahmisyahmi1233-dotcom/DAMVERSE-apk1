import React, { useState, useEffect } from 'react';
import { MainMenu } from './screens/MainMenu';
import { RegionSelect } from './screens/RegionSelect';
import { GameScreen } from './screens/GameScreen';
import { LoginModal } from './screens/LoginModal';
import { SettingsModal } from './components/SettingsModal';

import { authManager } from './lib/auth';
import { SaveManager } from './lib/gameSave';
import { soundManager } from './lib/audio';
import { 
  UserProfile, 
  GameSaveData, 
  GameSettings, 
  RegionInfo, 
  DamType 
} from './types/game';

export const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<'menu' | 'region_select' | 'game'>('menu');
  const [user, setUser] = useState<UserProfile | null>(null);
  const [saveData, setSaveData] = useState<GameSaveData | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [hasSavedGame, setHasSavedGame] = useState(false);

  const [settings, setSettings] = useState<GameSettings>({
    graphicsPreset: 'HIGH',
    resolutionScale: 1.0,
    shadows: true,
    postProcessing: true,
    masterVolume: 0.8,
    sfxVolume: 0.85,
    ambientVolume: 0.75,
    musicVolume: 0.6,
    touchSensitivity: 1.2,
    invertY: false,
  });

  // Subscribe to auth state
  useEffect(() => {
    const unsubscribe = authManager.subscribe((profile) => {
      setUser(profile);
    });

    // Check if any existing saves exist
    const slots = SaveManager.listLocalSlots();
    if (slots.length > 0) {
      setHasSavedGame(true);
    }

    return () => unsubscribe();
  }, []);

  const handleContinue = async () => {
    soundManager.resume();
    const loaded = await SaveManager.loadGame(1, user?.id);
    if (loaded) {
      setSaveData(loaded);
      setCurrentScreen('game');
    } else {
      // Create fresh default save
      const fresh = SaveManager.getDefaultSave();
      setSaveData(fresh);
      setCurrentScreen('game');
    }
  };

  const handleNewGame = () => {
    soundManager.resume();
    setCurrentScreen('region_select');
  };

  const handleRegionSelected = (region: RegionInfo, damType: DamType) => {
    const newSave = SaveManager.getDefaultSave(region.id, damType);
    newSave.saveName = `${region.damName} Construction`;
    setSaveData(newSave);
    setCurrentScreen('game');
  };

  return (
    <div className="w-screen h-screen overflow-hidden bg-slate-950 font-sans select-none">
      {currentScreen === 'menu' && (
        <MainMenu
          user={user}
          hasSavedGame={hasSavedGame}
          onContinue={handleContinue}
          onNewGame={handleNewGame}
          onOpenMap={() => setCurrentScreen('region_select')}
          onOpenAuth={() => setShowAuthModal(true)}
          onOpenSettings={() => setShowSettingsModal(true)}
        />
      )}

      {currentScreen === 'region_select' && (
        <RegionSelect
          onSelectRegion={handleRegionSelected}
          onBack={() => setCurrentScreen('menu')}
        />
      )}

      {currentScreen === 'game' && saveData && (
        <GameScreen
          initialSaveData={saveData}
          user={user}
          settings={settings}
          onUpdateSettings={setSettings}
          onExitToMenu={() => {
            const slots = SaveManager.listLocalSlots();
            setHasSavedGame(slots.length > 0);
            setCurrentScreen('menu');
          }}
        />
      )}

      {/* Auth Modal */}
      {showAuthModal && (
        <LoginModal
          onClose={() => setShowAuthModal(false)}
          onSuccess={() => {
            setShowAuthModal(false);
          }}
        />
      )}

      {/* Top Menu Settings Modal */}
      {showSettingsModal && (
        <SettingsModal
          settings={settings}
          user={user}
          onUpdatePreset={(preset) => setSettings({ ...settings, graphicsPreset: preset })}
          onUpdateVolume={(master, sfx, ambient) => {
            soundManager.setVolumes(master, sfx, ambient);
            setSettings({ ...settings, masterVolume: master, sfxVolume: sfx, ambientVolume: ambient });
          }}
          onManualSave={() => {}}
          isSaving={false}
          saveStatus={null}
          onExitToMenu={() => setShowSettingsModal(false)}
          onClose={() => setShowSettingsModal(false)}
        />
      )}
    </div>
  );
};
