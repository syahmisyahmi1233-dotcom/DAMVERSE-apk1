import * as THREE from 'three';
import { DamType } from '../../types/game';

export class DamWorld {
  public group: THREE.Group;
  public radialGates: THREE.Group[] = [];
  public streetLights: THREE.PointLight[] = [];
  public stageObjects: Record<number, THREE.Object3D[]> = {};
  public damHeight = 150;
  public damCrestY = 148;

  constructor(scene: THREE.Scene, damType: DamType = 'concrete_gravity') {
    this.group = new THREE.Group();
    scene.add(this.group);

    this.buildTerrain();
    this.buildDamStructure(damType);
    this.buildIntakeAndPenstocks();
    this.buildPowerhouseAndSubstation();
    this.buildDownstreamTownship();
  }

  private buildTerrain() {
    // 1. Left Mountain Ridge
    const leftMtnGeom = new THREE.ConeGeometry(140, 220, 7);
    leftMtnGeom.scale(1.2, 1, 2.5);
    const mtnMat = new THREE.MeshStandardMaterial({
      color: 0x224d26, // lush tropical rainforest green
      roughness: 0.9,
      metalness: 0.05,
      flatShading: true,
    });

    const leftMtn = new THREE.Mesh(leftMtnGeom, mtnMat);
    leftMtn.position.set(-160, 90, 0);
    leftMtn.receiveShadow = true;
    leftMtn.castShadow = true;
    this.group.add(leftMtn);

    // 2. Right Mountain Ridge
    const rightMtn = leftMtn.clone();
    rightMtn.position.set(160, 90, 0);
    this.group.add(rightMtn);

    // Additional mountain backdrops
    const backMtn1 = leftMtn.clone();
    backMtn1.scale.set(1.5, 1.3, 1.5);
    backMtn1.position.set(-200, 110, -260);
    this.group.add(backMtn1);

    const backMtn2 = leftMtn.clone();
    backMtn2.scale.set(1.6, 1.4, 1.6);
    backMtn2.position.set(220, 120, -280);
    this.group.add(backMtn2);

    // 3. Valley Riverbed Floor
    const floorGeom = new THREE.PlaneGeometry(600, 800, 16, 16);
    floorGeom.rotateX(-Math.PI / 2);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x33442a,
      roughness: 0.95,
    });
    const floor = new THREE.Mesh(floorGeom, floorMat);
    floor.position.set(0, 34, 100);
    floor.receiveShadow = true;
    this.group.add(floor);

    // 4. Tropical Rainforest Trees (Instanced procedural forest)
    this.spawnTropicalForest();
  }

  private spawnTropicalForest() {
    const trunkGeom = new THREE.CylinderGeometry(0.8, 1.2, 8, 5);
    const foliageGeom = new THREE.DodecahedronGeometry(5, 1);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5a3d28, roughness: 0.9 });
    const foliageMat = new THREE.MeshStandardMaterial({ color: 0x1f5e26, roughness: 0.8, flatShading: true });

    for (let i = 0; i < 90; i++) {
      const side = Math.random() > 0.5 ? 1 : -1;
      const x = side * (75 + Math.random() * 110);
      const z = (Math.random() - 0.5) * 450;
      const y = 35 + (Math.abs(x) - 70) * 0.55;

      const tree = new THREE.Group();
      const trunk = new THREE.Mesh(trunkGeom, trunkMat);
      trunk.position.y = 4;
      trunk.castShadow = true;

      const foliage = new THREE.Mesh(foliageGeom, foliageMat);
      foliage.position.y = 9;
      foliage.scale.set(0.9 + Math.random() * 0.6, 1.1 + Math.random() * 0.6, 0.9 + Math.random() * 0.6);
      foliage.castShadow = true;

      tree.add(trunk);
      tree.add(foliage);
      tree.position.set(x, y, z);
      this.group.add(tree);
    }
  }

  private buildDamStructure(damType: DamType) {
    const concreteColor = damType === 'rock_fill' ? 0x6e6860 : 0x9fa4a6;
    const concreteMat = new THREE.MeshStandardMaterial({
      color: concreteColor,
      roughness: 0.85,
      metalness: 0.12,
    });

    // Main Left Wing Monolith
    const leftWingGeom = new THREE.BoxGeometry(60, 115, 45);
    const leftWing = new THREE.Mesh(leftWingGeom, concreteMat);
    leftWing.position.set(-52, 90, 0);
    leftWing.castShadow = true;
    leftWing.receiveShadow = true;
    this.group.add(leftWing);

    // Main Right Wing Monolith
    const rightWing = leftWing.clone();
    rightWing.position.set(52, 90, 0);
    this.group.add(rightWing);

    // Center Spillway Structure (Sloped chute)
    const chuteGeom = new THREE.BoxGeometry(42, 28, 90);
    chuteGeom.rotateX(Math.PI / 4.2);
    const chute = new THREE.Mesh(chuteGeom, concreteMat);
    chute.position.set(0, 80, 28);
    chute.castShadow = true;
    chute.receiveShadow = true;
    this.group.add(chute);

    // Spillway Piers separating the radial gates
    const pierGeom = new THREE.BoxGeometry(2.5, 24, 28);
    for (let i = -1.5; i <= 1.5; i += 1.0) {
      const pier = new THREE.Mesh(pierGeom, concreteMat);
      pier.position.set(i * 10, 142, 6);
      pier.castShadow = true;
      this.group.add(pier);
    }

    // 4 Animated Radial Tainter Gates
    const gateMat = new THREE.MeshStandardMaterial({
      color: 0x992222, // Safety industrial red steel
      metalness: 0.7,
      roughness: 0.35,
    });

    for (let i = -1.5; i <= 1.5; i += 1.0) {
      const gatePivot = new THREE.Group();
      gatePivot.position.set(i * 10 + (i < 0 ? 5 : -5), 140, 10);

      const leafGeom = new THREE.CylinderGeometry(7, 7, 7, 12, 1, false, 0, Math.PI / 3);
      leafGeom.rotateZ(Math.PI / 2);
      leafGeom.rotateX(-Math.PI / 6);
      const leaf = new THREE.Mesh(leafGeom, gateMat);
      leaf.position.set(0, 0, -5);
      gatePivot.add(leaf);

      this.radialGates.push(gatePivot);
      this.group.add(gatePivot);
    }

    // Dam Crest Roadway (Asphalt road connecting both mountains)
    const roadGeom = new THREE.BoxGeometry(160, 3, 16);
    const roadMat = new THREE.MeshStandardMaterial({
      color: 0x2b2e33,
      roughness: 0.9,
    });
    const road = new THREE.Mesh(roadGeom, roadMat);
    road.position.set(0, this.damCrestY, 0);
    road.receiveShadow = true;
    this.group.add(road);

    // Parapet safety rails
    const railGeom = new THREE.BoxGeometry(160, 1.4, 0.6);
    const railMat = new THREE.MeshStandardMaterial({ color: 0xdde2e5, roughness: 0.4 });
    const frontRail = new THREE.Mesh(railGeom, railMat);
    frontRail.position.set(0, this.damCrestY + 2.2, 7.8);
    const backRail = new THREE.Mesh(railGeom, railMat);
    backRail.position.set(0, this.damCrestY + 2.2, -7.8);
    this.group.add(frontRail);
    this.group.add(backRail);

    // Street light poles along crest
    for (let x = -70; x <= 70; x += 35) {
      const poleGeom = new THREE.CylinderGeometry(0.2, 0.25, 7, 6);
      const pole = new THREE.Mesh(poleGeom, railMat);
      pole.position.set(x, this.damCrestY + 3.5, 7.2);
      this.group.add(pole);

      const light = new THREE.PointLight(0xffea99, 0.8, 45);
      light.position.set(x, this.damCrestY + 7, 6.5);
      this.streetLights.push(light);
      this.group.add(light);
    }
  }

  private buildIntakeAndPenstocks() {
    // Upstream Intake Towers
    const towerGeom = new THREE.BoxGeometry(12, 60, 12);
    const towerMat = new THREE.MeshStandardMaterial({ color: 0x6e7880, roughness: 0.7 });

    for (let i = 0; i < 4; i++) {
      const tower = new THREE.Mesh(towerGeom, towerMat);
      tower.position.set(-45 + i * 30, 115, -28);
      tower.castShadow = true;
      this.group.add(tower);
    }

    // 4 Heavy Steel Penstocks (Descending into the powerhouse)
    const penstockGeom = new THREE.CylinderGeometry(2.4, 2.4, 115, 12);
    penstockGeom.rotateX(Math.PI / 3.4);
    const penstockMat = new THREE.MeshStandardMaterial({
      color: 0x3d444d, // Dark industrial carbon steel
      metalness: 0.85,
      roughness: 0.3,
    });

    for (let i = 0; i < 4; i++) {
      const penstock = new THREE.Mesh(penstockGeom, penstockMat);
      penstock.position.set(-45 + i * 30, 88, 42);
      penstock.castShadow = true;
      this.group.add(penstock);
    }
  }

  private buildPowerhouseAndSubstation() {
    // 1. Powerhouse Building (At the base of the dam)
    const powerhouseGeom = new THREE.BoxGeometry(130, 25, 42);
    const powerhouseMat = new THREE.MeshStandardMaterial({
      color: 0x7f8891,
      roughness: 0.65,
    });
    const powerhouse = new THREE.Mesh(powerhouseGeom, powerhouseMat);
    powerhouse.position.set(0, 47, 95);
    powerhouse.castShadow = true;
    powerhouse.receiveShadow = true;
    this.group.add(powerhouse);

    // Powerhouse windows / ventilation louver
    const louversGeom = new THREE.BoxGeometry(110, 6, 0.5);
    const louversMat = new THREE.MeshStandardMaterial({ color: 0x223344, metalness: 0.8 });
    const louvers = new THREE.Mesh(louversGeom, louversMat);
    louvers.position.set(0, 52, 116.2);
    this.group.add(louvers);

    // 2. High-Voltage Step-Up Substation & Transformers
    const transformerMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.7 });
    for (let i = 0; i < 4; i++) {
      const transf = new THREE.Mesh(new THREE.BoxGeometry(8, 10, 8), transformerMat);
      transf.position.set(-50 + i * 33, 40, 125);
      transf.castShadow = true;
      this.group.add(transf);

      // Ceramic insulator bushings
      const bushing = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.5, 4, 8), new THREE.MeshStandardMaterial({ color: 0xd97706 }));
      bushing.position.set(-50 + i * 33, 47, 125);
      this.group.add(bushing);
    }

    // 3. Transmission Pylons (Lattice steel high-voltage towers)
    this.buildTransmissionPylon(70, 35, 160);
    this.buildTransmissionPylon(130, 75, 230);
    this.buildTransmissionPylon(-90, 65, 240);
  }

  private buildTransmissionPylon(x: number, y: number, z: number) {
    const tower = new THREE.Group();
    const steelMat = new THREE.MeshStandardMaterial({ color: 0x88929b, metalness: 0.85, roughness: 0.3 });

    // Main tower body
    const bodyGeom = new THREE.CylinderGeometry(1.2, 4.5, 42, 4);
    const body = new THREE.Mesh(bodyGeom, steelMat);
    body.position.y = 21;
    body.castShadow = true;
    tower.add(body);

    // Cross-arms
    const armGeom = new THREE.BoxGeometry(22, 1.2, 1.5);
    const arm1 = new THREE.Mesh(armGeom, steelMat);
    arm1.position.y = 35;
    const arm2 = new THREE.Mesh(armGeom, steelMat);
    arm2.position.y = 28;
    tower.add(arm1);
    tower.add(arm2);

    tower.position.set(x, y, z);
    this.group.add(tower);
  }

  private buildDownstreamTownship() {
    const village = new THREE.Group();

    // Traditional Malaysian stilt kampung houses + modern engineering offices
    const houseWoodMat = new THREE.MeshStandardMaterial({ color: 0x6e472f, roughness: 0.85 });
    const roofMat = new THREE.MeshStandardMaterial({ color: 0xa83232, roughness: 0.6 });

    for (let i = 0; i < 12; i++) {
      const side = i % 2 === 0 ? 1 : -1;
      const x = side * (55 + (i * 7));
      const z = 220 + i * 18;
      const y = 35;

      const house = new THREE.Group();
      // Stilts
      for (let sx = -3; sx <= 3; sx += 6) {
        for (let sz = -4; sz <= 4; sz += 8) {
          const stilt = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 3, 6), houseWoodMat);
          stilt.position.set(sx, 1.5, sz);
          house.add(stilt);
        }
      }

      // Walls
      const walls = new THREE.Mesh(new THREE.BoxGeometry(8, 5, 10), houseWoodMat);
      walls.position.y = 5.5;
      walls.castShadow = true;
      house.add(walls);

      // Pitch roof
      const roofGeom = new THREE.ConeGeometry(7.5, 4.5, 4);
      roofGeom.rotateY(Math.PI / 4);
      const roof = new THREE.Mesh(roofGeom, roofMat);
      roof.position.y = 10.2;
      roof.scale.set(1.1, 1, 1.3);
      roof.castShadow = true;
      house.add(roof);

      house.position.set(x, y, z);
      village.add(house);
    }

    // Concrete road bridge spanning the river
    const bridge = new THREE.Mesh(
      new THREE.BoxGeometry(75, 2.5, 12),
      new THREE.MeshStandardMaterial({ color: 0x82888f, roughness: 0.8 })
    );
    bridge.position.set(0, 42, 280);
    village.add(bridge);

    this.group.add(village);
  }

  public updateGates(spillwayGatePercent: number) {
    const maxRot = Math.PI / 3.8;
    const currentRot = (spillwayGatePercent / 100) * maxRot;
    for (const gate of this.radialGates) {
      gate.rotation.x = -currentRot;
    }
  }

  public updateNightLighting(isNight: boolean) {
    for (const light of this.streetLights) {
      light.intensity = isNight ? 1.4 : 0.0;
    }
  }
}
