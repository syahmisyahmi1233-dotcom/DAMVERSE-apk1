import * as THREE from 'three';

export class WaterSystem {
  public reservoirWaterMesh: THREE.Mesh;
  public spillwayWaterMesh: THREE.Mesh;
  public sprayParticles: THREE.Points;
  public tailraceRiverMesh: THREE.Mesh;

  private sprayCount = 300;
  private time = 0;

  constructor(scene: THREE.Scene) {
    // 1. Upstream Reservoir Surface
    const reservoirGeom = new THREE.PlaneGeometry(360, 400, 32, 32);
    reservoirGeom.rotateX(-Math.PI / 2);

    const reservoirMat = new THREE.MeshStandardMaterial({
      color: 0x1a7088,
      roughness: 0.12,
      metalness: 0.1,
      transparent: true,
      opacity: 0.88,
    });

    this.reservoirWaterMesh = new THREE.Mesh(reservoirGeom, reservoirMat);
    this.reservoirWaterMesh.position.set(0, 140, -180);
    this.reservoirWaterMesh.receiveShadow = true;
    scene.add(this.reservoirWaterMesh);

    // 2. Spillway Chute Water Cascade
    // Follows the slope of the spillway from crest (y=138, z=0) down to stilling basin (y=42, z=95)
    const spillwayGeom = new THREE.PlaneGeometry(32, 115, 12, 24);
    spillwayGeom.rotateX(Math.PI / 3.4);

    const spillwayMat = new THREE.MeshStandardMaterial({
      color: 0x88ccff,
      roughness: 0.25,
      metalness: 0.05,
      transparent: true,
      opacity: 0.0, // starts invisible until gates open
      wireframe: false,
    });

    this.spillwayWaterMesh = new THREE.Mesh(spillwayGeom, spillwayMat);
    this.spillwayWaterMesh.position.set(0, 92, 45);
    scene.add(this.spillwayWaterMesh);

    // 3. Flip Bucket Spray Particles (white foam explosion at the bottom)
    const sprayGeom = new THREE.BufferGeometry();
    const positions = new Float32Array(this.sprayCount * 3);
    for (let i = 0; i < this.sprayCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 36;
      positions[i * 3 + 1] = 42 + Math.random() * 20;
      positions[i * 3 + 2] = 85 + Math.random() * 35;
    }
    sprayGeom.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const sprayMat = new THREE.PointsMaterial({
      color: 0xf5faff,
      size: 2.2,
      transparent: true,
      opacity: 0.0,
    });

    this.sprayParticles = new THREE.Points(sprayGeom, sprayMat);
    scene.add(this.sprayParticles);

    // 4. Downstream River Channel
    const riverGeom = new THREE.PlaneGeometry(55, 380, 16, 24);
    riverGeom.rotateX(-Math.PI / 2);

    const riverMat = new THREE.MeshStandardMaterial({
      color: 0x1b5566,
      roughness: 0.2,
      metalness: 0.1,
      transparent: true,
      opacity: 0.85,
    });

    this.tailraceRiverMesh = new THREE.Mesh(riverGeom, riverMat);
    this.tailraceRiverMesh.position.set(0, 36.5, 230);
    this.tailraceRiverMesh.receiveShadow = true;
    scene.add(this.tailraceRiverMesh);
  }

  public update(delta: number, waterLevelM: number, spillwayGatePercent: number) {
    this.time += delta;

    // 1. Physically position the reservoir water surface based on simulated head level
    // Water level simulated between 100m and 160m
    const targetY = 35 + ((waterLevelM - 90) / 70) * 115;
    this.reservoirWaterMesh.position.y += (targetY - this.reservoirWaterMesh.position.y) * 0.1;

    // Gentle wave pulsation
    const pos = this.reservoirWaterMesh.geometry.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const u = pos.getX(i);
      const v = pos.getZ(i);
      const wave = Math.sin(u * 0.08 + this.time * 2.2) * Math.cos(v * 0.07 + this.time * 1.8) * 0.28;
      pos.setY(i, wave);
    }
    pos.needsUpdate = true;

    // 2. Spillway cascade visual
    const spillwayMat = this.spillwayWaterMesh.material as THREE.MeshStandardMaterial;
    const sprayMat = this.sprayParticles.material as THREE.PointsMaterial;

    if (spillwayGatePercent > 0) {
      const gateRatio = spillwayGatePercent / 100;
      spillwayMat.opacity = Math.min(0.92, 0.4 + gateRatio * 0.52);

      // Jiggle spillway water mesh to simulate roaring torrent
      const sPos = this.spillwayWaterMesh.geometry.attributes.position;
      for (let i = 0; i < sPos.count; i++) {
        const u = sPos.getX(i);
        const turbulence = Math.sin(u * 0.4 + this.time * 25.0) * (0.15 + gateRatio * 0.35);
        sPos.setZ(i, turbulence);
      }
      sPos.needsUpdate = true;

      // Flip bucket spray bursting
      sprayMat.opacity = Math.min(0.9, gateRatio * 0.95);
      const sprayPos = this.sprayParticles.geometry.attributes.position.array as Float32Array;
      for (let i = 0; i < this.sprayCount; i++) {
        sprayPos[i * 3 + 1] += (Math.random() - 0.45) * 15 * delta;
        sprayPos[i * 3 + 2] += delta * (40 + gateRatio * 60);
        if (sprayPos[i * 3 + 2] > 140) {
          sprayPos[i * 3] = (Math.random() - 0.5) * (28 + gateRatio * 15);
          sprayPos[i * 3 + 1] = 40 + Math.random() * (8 + gateRatio * 20);
          sprayPos[i * 3 + 2] = 85 + Math.random() * 8;
        }
      }
      this.sprayParticles.geometry.attributes.position.needsUpdate = true;
    } else {
      spillwayMat.opacity = Math.max(0, spillwayMat.opacity - delta * 2.0);
      sprayMat.opacity = Math.max(0, sprayMat.opacity - delta * 3.0);
    }
  }
}
