import * as THREE from 'three';

export class VehicleController {
  public mesh: THREE.Group;
  public position: THREE.Vector3;
  public heading = 0; // angle in radians
  public speed = 0; // forward speed
  public isPlayerInside = false;

  private wheels: THREE.Mesh[] = [];
  private frontWheelPivots: THREE.Group[] = [];
  private headlights: THREE.SpotLight[] = [];
  private amberBeacon: THREE.PointLight;

  private maxSpeed = 32.0;
  private accel = 18.0;
  private brakeDecel = 28.0;
  private steerSpeed = 2.4;

  constructor(scene: THREE.Scene, initialPos = new THREE.Vector3(12, 150.2, 0)) {
    this.position = initialPos.clone();
    this.mesh = new THREE.Group();
    this.mesh.position.copy(this.position);
    scene.add(this.mesh);

    // 1. Truck Body & Cabin
    const bodyMat = new THREE.MeshStandardMaterial({
      color: 0x2563eb, // Utility Royal Blue
      metalness: 0.6,
      roughness: 0.35,
    });
    const blackMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.8 });
    const glassMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.1, metalness: 0.9 });

    // Chassis / Bed
    const bed = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.7, 4.8), bodyMat);
    bed.position.y = 0.8;
    bed.castShadow = true;
    this.mesh.add(bed);

    // Cabin
    const cab = new THREE.Mesh(new THREE.BoxGeometry(2.3, 1.1, 2.4), bodyMat);
    cab.position.set(0, 1.6, -0.4);
    cab.castShadow = true;
    this.mesh.add(cab);

    // Windshield
    const windshield = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.75, 0.1), glassMat);
    windshield.position.set(0, 1.7, -1.62);
    windshield.rotateX(0.2);
    this.mesh.add(windshield);

    // Roll Bar in back
    const rollBar = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 2.3), blackMat);
    rollBar.rotateZ(Math.PI / 2);
    rollBar.position.set(0, 2.1, 0.8);
    this.mesh.add(rollBar);

    // Amber roof safety beacon
    this.amberBeacon = new THREE.PointLight(0xf59e0b, 0, 15);
    this.amberBeacon.position.set(0, 2.3, -0.4);
    this.mesh.add(this.amberBeacon);

    // 2. 4 Chunky Offroad Wheels
    const tireMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.95 });
    const wheelGeom = new THREE.CylinderGeometry(0.48, 0.48, 0.35, 14);
    wheelGeom.rotateZ(Math.PI / 2);

    const wheelOffsets = [
      { x: -1.2, z: -1.5, isFront: true },
      { x: 1.2, z: -1.5, isFront: true },
      { x: -1.2, z: 1.5, isFront: false },
      { x: 1.2, z: 1.5, isFront: false },
    ];

    for (const off of wheelOffsets) {
      const wheel = new THREE.Mesh(wheelGeom, tireMat);
      wheel.castShadow = true;

      if (off.isFront) {
        const pivot = new THREE.Group();
        pivot.position.set(off.x, 0.5, off.z);
        wheel.position.set(0, 0, 0);
        pivot.add(wheel);
        this.mesh.add(pivot);
        this.frontWheelPivots.push(pivot);
      } else {
        wheel.position.set(off.x, 0.5, off.z);
        this.mesh.add(wheel);
      }
      this.wheels.push(wheel);
    }

    // 3. Headlights (Two forward spotlights)
    for (const sx of [-0.8, 0.8]) {
      const spot = new THREE.SpotLight(0xfffae0, 0, 80, Math.PI / 5, 0.4);
      spot.position.set(sx, 1.0, -2.4);
      spot.target.position.set(sx, 0.2, -18);
      this.mesh.add(spot);
      this.mesh.add(spot.target);
      this.headlights.push(spot);
    }
  }

  public update(
    delta: number,
    moveInput: { x: number; y: number },
    isNight: boolean,
    camera: THREE.PerspectiveCamera
  ) {
    // Amber beacon strobe
    this.amberBeacon.intensity = this.isPlayerInside ? (Math.sin(performance.now() * 0.012) > 0 ? 1.6 : 0.2) : 0;

    // Headlights active at night when driving
    for (const h of this.headlights) {
      h.intensity = this.isPlayerInside && isNight ? 2.5 : 0;
    }

    if (this.isPlayerInside) {
      // Steering
      const steerInput = -moveInput.x;
      this.heading += steerInput * this.steerSpeed * delta * (Math.abs(this.speed) / this.maxSpeed + 0.2);

      // Turn front wheels visually
      for (const p of this.frontWheelPivots) {
        p.rotation.y = steerInput * 0.45;
      }

      // Acceleration & Braking
      const throttle = -moveInput.y;
      if (Math.abs(throttle) > 0.05) {
        this.speed += throttle * this.accel * delta;
        this.speed = Math.max(-this.maxSpeed * 0.4, Math.min(this.maxSpeed, this.speed));
      } else {
        // Natural friction decay
        this.speed *= Math.pow(0.85, delta * 30);
      }

      // Roll wheels
      const wheelRoll = (this.speed / 0.48) * delta;
      for (const w of this.wheels) {
        w.rotation.x += wheelRoll;
      }

      // Move vehicle along heading
      const forwardX = -Math.sin(this.heading);
      const forwardZ = -Math.cos(this.heading);

      this.position.x += forwardX * this.speed * delta;
      this.position.z += forwardZ * this.speed * delta;

      // Keep inside dam crest roadway boundary
      this.position.x = Math.max(-75, Math.min(75, this.position.x));
      this.position.z = Math.max(-6.5, Math.min(6.5, this.position.z));

      this.mesh.position.copy(this.position);
      this.mesh.rotation.y = this.heading;

      // Chase Camera behind truck
      this.updateDrivingCamera(camera);
    }
  }

  private updateDrivingCamera(camera: THREE.PerspectiveCamera) {
    const camDist = 9.5;
    const camHeight = 3.8;

    const backX = Math.sin(this.heading) * camDist;
    const backZ = Math.cos(this.heading) * camDist;

    const targetPos = this.position.clone().add(new THREE.Vector3(0, 1.2, 0));
    const camPos = this.position.clone().add(new THREE.Vector3(backX, camHeight, backZ));

    camera.position.lerp(camPos, 0.14);
    camera.lookAt(targetPos);
  }

  public getDriverExitPos(): THREE.Vector3 {
    // Left side of truck
    const sideX = Math.cos(this.heading) * 2.2;
    const sideZ = -Math.sin(this.heading) * 2.2;
    return this.position.clone().add(new THREE.Vector3(sideX, 0, sideZ));
  }
}
