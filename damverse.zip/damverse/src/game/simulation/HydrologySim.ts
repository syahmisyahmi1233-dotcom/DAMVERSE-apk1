import { ReservoirState, WeatherType } from '../../types/game';

export class HydrologySim {
  public static update(
    res: ReservoirState,
    turbinesTotalFlow: number,
    deltaSeconds: number
  ): ReservoirState {
    const next = { ...res };

    // 1. Inflow calculation based on weather
    let baseInflow = 130.0;
    if (next.weather === 'monsoon_rain') {
      baseInflow = 620.0 + Math.sin(performance.now() * 0.0008) * 140.0; // Monsoon surge
    } else if (next.weather === 'overcast') {
      baseInflow = 190.0;
    } else {
      baseInflow = 125.0 + Math.sin(performance.now() * 0.0004) * 15.0;
    }
    next.inflowCms = baseInflow;

    // 2. Net Hydraulic Head above spillway crest (EL 138m)
    const spillwayCrestEl = 138.0;
    const headOverCrest = Math.max(0, next.waterLevelM - spillwayCrestEl);

    // 3. Spillway discharge formula: Q = C * L * H^1.5 * gateOpeningRatio
    // C = 2.18 (Ogee crest coefficient), L = 4 bays * 7.5m = 30m
    const gateRatio = next.spillwayGatePercent / 100;
    if (gateRatio > 0 && headOverCrest > 0) {
      next.spillwayDischargeCms = 2.18 * 30 * Math.pow(headOverCrest, 1.5) * gateRatio;
    } else {
      next.spillwayDischargeCms = 0;
    }

    // 4. Environmental base flow
    next.environmentalFlowCms = 25.0;

    // 5. Total Outflow
    next.totalOutflowCms = next.spillwayDischargeCms + turbinesTotalFlow + next.environmentalFlowCms;

    // 6. Net storage rate (m3/s)
    next.netStorageRateCms = next.inflowCms - next.totalOutflowCms;

    // 7. Reservoir volume update (1 MCM = 1,000,000 m3)
    // Accelerated time scale (1 real sec = 20 simulation secs)
    const simTimeScale = 25;
    const deltaVolumeM3 = next.netStorageRateCms * deltaSeconds * simTimeScale;
    next.currentVolumeMCM = Math.max(100, Math.min(next.maxVolumeMCM, next.currentVolumeMCM + deltaVolumeM3 / 1_000_000));

    // 8. Water level based on reservoir hypsometric curve
    const volumeRatio = next.currentVolumeMCM / next.maxVolumeMCM;
    next.waterLevelM = next.minOperatingLevelM + volumeRatio * (next.maxLevelM - next.minOperatingLevelM);

    // 9. Flood warning alarms
    next.floodAlarm = next.waterLevelM >= 152.0;

    return next;
  }
}
