import { TurbineState, Finances, GridState } from '../../types/game';

export class PowerGridSim {
  public static updateTurbines(
    turbines: TurbineState[],
    headM: number
  ): { updatedTurbines: TurbineState[]; totalPowerMW: number; totalFlowCms: number } {
    let totalPowerMW = 0;
    let totalFlowCms = 0;

    const rho = 1000; // kg/m3
    const g = 9.81; // m/s2

    const updatedTurbines = turbines.map(t => {
      if (!t.active || headM <= 10) {
        return {
          ...t,
          flowCms: 0,
          outputMW: 0,
          bearingTempC: Math.max(30, t.bearingTempC - 0.05),
          vibrationMmS: 0.1,
        };
      }

      // Flow through wicket gates
      const flow = t.maxFlowCms * (t.wicketGatePercent / 100);

      // P = eta * rho * g * Q * H / 1e6 (MW)
      const theoreticalMW = (t.efficiency * rho * g * flow * headM) / 1_000_000;
      const actualMW = Math.min(t.ratedCapacityMW, theoreticalMW);

      totalPowerMW += actualMW;
      totalFlowCms += flow;

      // Operating telemetry
      const targetTemp = 48 + (actualMW / t.ratedCapacityMW) * 24;
      const bearingTemp = t.bearingTempC + (targetTemp - t.bearingTempC) * 0.05;
      const vibration = 0.8 + (actualMW / t.ratedCapacityMW) * 1.2;

      return {
        ...t,
        flowCms: flow,
        outputMW: actualMW,
        bearingTempC: bearingTemp,
        vibrationMmS: vibration,
      };
    });

    return { updatedTurbines, totalPowerMW, totalFlowCms };
  }

  public static updateGrid(totalGenerationMW: number, targetDemandMW = 180): GridState {
    // Grid frequency deviations from 50.00 Hz
    // Overgeneration increases frequency, undergeneration decreases frequency
    const imbalanceMW = totalGenerationMW - targetDemandMW;
    const frequencyHz = Math.max(47.5, Math.min(52.5, 50.0 + imbalanceMW * 0.005));

    const stabilityIndex = Math.max(0, 1.0 - Math.abs(frequencyHz - 50.0) / 1.5);
    const blackoutRisk = frequencyHz < 48.8 || frequencyHz > 51.2;

    return {
      frequencyHz,
      targetDemandMW,
      totalGenerationMW,
      stabilityIndex,
      blackoutRisk,
    };
  }

  public static updateFinances(
    finances: Finances,
    totalPowerMW: number,
    deltaSeconds: number
  ): Finances {
    // Tariff RM 0.38 per kWh = RM 380 per MWh
    const mwhProduced = totalPowerMW * (deltaSeconds / 3600) * 25; // accelerated simulation
    const revenueEarned = mwhProduced * (finances.tariffPerKWhRM * 1000);
    const opex = (finances.operatingExpensesPerHourRM / 3600) * deltaSeconds * 25;

    const netRM = revenueEarned - opex;

    return {
      ...finances,
      fundsRM: Math.max(0, finances.fundsRM + netRM),
      totalRevenueRM: finances.totalRevenueRM + revenueEarned,
      netRevenueRateRMPerHour: (totalPowerMW * finances.tariffPerKWhRM * 1000) - finances.operatingExpensesPerHourRM,
    };
  }
}
