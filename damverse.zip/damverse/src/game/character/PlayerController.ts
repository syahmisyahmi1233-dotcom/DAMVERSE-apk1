import * as THREE from 'three';

export class PlayerController {
  public mesh: THREE.Group;
  public position: THREE.Vector3;
  public velocity: THREE.Vector3 = new THREE.Vector3();
  public isGrounded = true;
  public isSprinting = false;
  public yaw = 0;
  public pitch = 0.25; // radians down

  private leftLeg: THREE.Mesh;
  private rightLeg: THREE.Mesh;
  private leftArm: THREE.Mesh;
  private rightArm: THREE.Mesh;
  private animTime = 0;

  private walkSpeed = 9.0;
  private sprintSpeed = 16.5;
  private jumpForce = 12.0;
  private gravity = 26.0;

  constructor(scene: THREE.Scene, initialPos = new THREE.Vector3(0, 149.5, 0)) {
    this.position = initialPos.clone();
    this.mesh = new THREE.Group();
    this.mesh.position.copy(this.position);
    scene.add(this.mesh);

    // Build 3D Engineer Character
    // Materials
    const skinMat = new THREE.MeshStandardMaterial({ color: 0xd49b74, roughness: 0.6 });
    const vestMat = new THREE.MeshStandardMaterial({ color: 0xccff00, roughness: 0.5 }); // High-vis lime
    const pantsMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.8 }); // Navy cargo pants
    const bootsMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.9 }); // Safety boots
    const helmetMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.3 }); // Yellow Hard Hat

    // 1. Torso with high-vis vest
    const torsoGeom = new THREE.BoxGeometry(0.9, 1.1, 0.55);
    const torso = new THREE.Mesh(torsoGeom, vestMat);
    torso.position.y = 1.35;
    torso.castShadow = true;
    this.mesh.add(torso);

    // Silver reflective band across vest
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.15, 0.57), new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.2 }));
    stripe.position.y = 1.35;
    this.mesh.add(stripe);

    // 2. Head
    const headGeom = new THREE.SphereGeometry(0.32, 12, 12);
    const head = new THREE.Mesh(headGeom, skinMat);
    head.position.y = 2.15;
    head.castShadow = true;
    this.mesh.add(head);

    // 3. Safety Hard Hat
    const helmetGeom = new THREE.CylinderGeometry(0.38, 0.42, 0.28, 12);
    const helmet = new THREE.Mesh(helmetGeom, helmetMat);
    helmet.position.y = 2.36;
    helmet.castShadow = true;
    this.mesh.add(helmet);

    // 4. Legs
    const legGeom = new THREE.BoxGeometry(0.3, 0.85, 0.3);
    legGeom.translate(0, -0.42, 0);

    this.leftLeg = new THREE.Mesh(legGeom, pantsMat);
    this.leftLeg.position.set(-0.25, 0.85, 0);
    this.leftLeg.castShadow = true;
    this.mesh.add(this.leftLeg);

    this.rightLeg = new THREE.Mesh(legGeom, pantsMat);
    this.rightLeg.position.set(0.25, 0.85, 0);
    this.rightLeg.castShadow = true;
    this.mesh.add(this.rightLeg);

    // Boots
    const bootGeom = new THREE.BoxGeometry(0.32, 0.25, 0.45);
    bootGeom.translate(0, -0.85, 0.06);
    this.leftLeg.add(new THREE.Mesh(bootGeom, bootsMat));
    this.rightLeg.add(new THREE.Mesh(bootGeom, bootsMat));

    // 5. Arms
    const armGeom = new THREE.BoxGeometry(0.24, 0.8, 0.24);
    armGeom.translate(0, -0.4, 0);

    this.leftArm = new THREE.Mesh(armGeom, vestMat);
    this.leftArm.position.set(-0.58, 1.8, 0);
    this.leftArm.castShadow = true;
    this.mesh.add(this.leftArm);

    this.rightArm = new THREE.Mesh(armGeom, vestMat);
    this.rightArm.position.set(0.58, 1.8, 0);
    this.rightArm.castShadow = true;
    this.mesh.add(this.rightArm);
  }

  public update(
    delta: number,
    moveInput: { x: number; y: number },
    sprint: boolean,
    camera: THREE.PerspectiveCamera
  ) {
    this.isSprinting = sprint;

    // Camera-relative movement
    const inputMagnitude = Math.sqrt(moveInput.x * moveInput.x + moveInput.y * moveInput.y);
    const isMoving = inputMagnitude > 0.08;

    if (isMoving) {
      // Calculate movement direction relative to camera yaw
      const forward = new THREE.Vector3(0, 0, -1).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw);
      const right = new THREE.Vector3(1, 0, 0).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw);

      const moveDir = new THREE.Vector3()
        .addScaledVector(right, moveInput.x)
        .addScaledVector(forward, -moveInput.y)
        .normalize();

      const speed = (this.isSprinting ? this.sprintSpeed : this.walkSpeed) * Math.min(1.0, inputMagnitude);
      this.velocity.x = moveDir.x * speed;
      this.velocity.z = moveDir.z * speed;

      // Rotate character mesh towards movement direction
      const targetAngle = Math.atan2(moveDir.x, moveDir.z);
      this.mesh.rotation.y = targetAngle;

      // Leg & Arm walking animation
      this.animTime += delta * (this.isSprinting ? 14 : 9);
      const swing = Math.sin(this.animTime) * 0.7;
      this.leftLeg.rotation.x = swing;
      this.rightLeg.rotation.x = -swing;
      this.leftArm.rotation.x = -swing;
      this.rightArm.rotation.x = swing;
    } else {
      this.velocity.x *= 0.7;
      this.velocity.z *= 0.7;
      // Return legs to neutral
      this.leftLeg.rotation.x *= 0.8;
      this.rightLeg.rotation.x *= 0.8;
      this.leftArm.rotation.x *= 0.8;
      this.rightArm.rotation.x *= 0.8;
    }

    // Gravity
    if (!this.isGrounded) {
      this.velocity.y -= this.gravity * delta;
    }

    // Apply movement
    this.position.x += this.velocity.x * delta;
    this.position.y += this.velocity.y * delta;
    this.position.z += this.velocity.z * delta;

    // Ground floor collision / dam crest limit
    const groundY = 149.5; // Dam crest elevation
    if (this.position.y <= groundY) {
      this.position.y = groundY;
      this.velocity.y = 0;
      this.isGrounded = true;
    }

    // Keep on playable dam road boundary (-75 to 75 x, -7 to 7 z)
    this.position.x = Math.max(-76, Math.min(76, this.position.x));
    this.position.z = Math.max(-7.2, Math.min(7.2, this.position.z));

    this.mesh.position.copy(this.position);

    // Update follow camera
    this.updateCamera(camera);
  }

  public jump() {
    if (this.isGrounded) {
      this.velocity.y = this.jumpForce;
      this.isGrounded = false;
    }
  }

  public rotateCamera(deltaYaw: number, deltaPitch: number) {
    this.yaw -= deltaYaw;
    this.pitch = Math.max(-0.4, Math.min(0.85, this.pitch + deltaPitch));
  }

  private updateCamera(camera: THREE.PerspectiveCamera) {
    const camDist = 6.8;
    const target = this.position.clone().add(new THREE.Vector3(0, 1.8, 0));

    const cx = target.x + Math.sin(this.yaw) * Math.cos(this.pitch) * camDist;
    const cy = target.y + Math.sin(this.pitch) * camDist + 0.6;
    const cz = target.z + Math.cos(this.yaw) * Math.cos(this.pitch) * camDist;

    camera.position.set(cx, cy, cz);
    camera.lookAt(target);
  }

  public setVisible(visible: boolean) {
    this.mesh.visible = visible;
  }
}
