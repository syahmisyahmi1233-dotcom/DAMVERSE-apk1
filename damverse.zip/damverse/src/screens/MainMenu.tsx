import React from 'react';
import { Play, RotateCcw, Map, Settings, UserCheck, Shield, HelpCircle, HardHat } from 'lucide-react';
import { UserProfile } from '../types/game';
import { soundManager } from '../lib/audio';

interface MainMenuProps {
  user: UserProfile | null;
  hasSavedGame: boolean;
  onContinue: () => void;
  onNewGame: () => void;
  onOpenMap: () => void;
  onOpenAuth: () => void;
  onOpenSettings: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  user,
  hasSavedGame,
  onContinue,
  onNewGame,
  onOpenMap,
  onOpenAuth,
  onOpenSettings,
}) => {
  return (
    <div className="fixed inset-0 bg-slate-950 text-slate-100 flex flex-col justify-between p-6 select-none z-30 overflow-hidden">
      {/* Background Graphic Accents */}
      <div className="absolute inset-0 bg-gradient-to-tr from-slate-950 via-slate-900 to-cyan-950/40 pointer-events-none" />
      <div className="absolute -top-40 -right-40 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Header: Account Status & Settings */}
      <div className="relative z-10 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-cyan-950 border border-cyan-500/60 flex items-center justify-center text-cyan-400 shadow-xl">
            <HardHat className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-mono font-bold text-cyan-400 tracking-wider">CIVIL HYDRAULIC SIMULATION</div>
            <div className="text-sm font-extrabold text-white">PENINSULAR & BORNEO BASINS</div>
          </div>
        </div>

        {/* User Profile Pill */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => { soundManager.playClick(); onOpenAuth(); }}
            className="bg-slate-900/80 backdrop-blur-md border border-slate-700 hover:border-cyan-500/80 px-3 py-1.5 rounded-xl flex items-center gap-2 text-xs font-bold text-slate-200 hover:text-white transition-all shadow-md active:scale-95"
          >
            {user ? (
              <>
                <UserCheck className="w-4 h-4 text-emerald-400" />
                <span>{user.username}</span>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-1.5 py-0.5 rounded border border-emerald-800">
                  {user.isGuest ? 'GUEST' : 'CLOUD'}
                </span>
              </>
            ) : (
              <>
                <Shield className="w-4 h-4 text-cyan-400" />
                <span>SIGN IN / REGISTER</span>
              </>
            )}
          </button>

          <button
            onClick={() => { soundManager.playClick(); onOpenSettings(); }}
            className="w-9 h-9 rounded-xl bg-slate-900/80 border border-slate-700 hover:border-slate-500 flex items-center justify-center text-slate-300 hover:text-white transition-all active:scale-95 shadow-md"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Center Branding & Title */}
      <div className="relative z-10 max-w-xl my-auto">
        <div className="inline-block bg-cyan-950/80 border border-cyan-500/40 text-cyan-400 font-mono text-[11px] font-bold px-3 py-1 rounded-full mb-2 tracking-widest">
          AAA 3D MOBILE HYDROELECTRIC SIMULATOR
        </div>
        <h1 className="text-5xl font-black tracking-tight text-white drop-shadow-md">
          DAM<span className="text-cyan-400">VERSE</span>
        </h1>
        <p className="text-sm text-slate-300 mt-2 max-w-lg leading-relaxed">
          Design, construct, and manage Malaysia’s massive hydroelectric dams. Control radial spillway gates during monsoon surges, operate Francis turbines, stabilize national 50Hz frequency, and drive offroad utility trucks across the crest.
        </p>
      </div>

      {/* Bottom Menu Navigation Buttons */}
      <div className="relative z-10 flex items-center gap-3">
        {hasSavedGame && (
          <button
            onClick={() => { soundManager.playClick(); onContinue(); }}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold px-6 py-3.5 rounded-2xl text-xs flex items-center gap-2 shadow-xl active:scale-95 transition-all border border-emerald-400/50"
          >
            <RotateCcw className="w-4 h-4" />
            <span>CONTINUE PROJECT</span>
          </button>
        )}

        <button
          onClick={() => { soundManager.playClick(); onNewGame(); }}
          className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold px-6 py-3.5 rounded-2xl text-xs flex items-center gap-2 shadow-xl active:scale-95 transition-all"
        >
          <Play className="w-4 h-4 fill-slate-950" />
          <span>START NEW DAM</span>
        </button>

        <button
          onClick={() => { soundManager.playClick(); onOpenMap(); }}
          className="bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 hover:border-slate-500 font-bold px-5 py-3.5 rounded-2xl text-xs flex items-center gap-2 shadow-lg active:scale-95 transition-all"
        >
          <Map className="w-4 h-4 text-cyan-400" />
          <span>MALAYSIA MAP</span>
        </button>

        <button
          onClick={() => { soundManager.playClick(); onOpenSettings(); }}
          className="bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 hover:border-slate-500 font-bold px-4 py-3.5 rounded-2xl text-xs flex items-center gap-2 shadow-lg active:scale-95 transition-all"
        >
          <Settings className="w-4 h-4 text-slate-400" />
          <span>GRAPHICS & AUDIO</span>
        </button>
      </div>
    </div>
  );
};
