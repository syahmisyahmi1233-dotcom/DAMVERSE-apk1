import React, { useState } from 'react';
import { 
  ArrowLeft, 
  MapPin, 
  Search, 
  Droplets, 
  Zap, 
  Layers, 
  ArrowRight, 
  Compass, 
  Mountain 
} from 'lucide-react';
import { MALAYSIA_REGIONS } from '../data/malaysiaRegions';
import { RegionInfo, DamType } from '../types/game';
import { soundManager } from '../lib/audio';

interface RegionSelectProps {
  onSelectRegion: (region: RegionInfo, damType: DamType) => void;
  onBack: () => void;
}

export const RegionSelect: React.FC<RegionSelectProps> = ({ onSelectRegion, onBack }) => {
  const [selectedRegionId, setSelectedRegionId] = useState<string>('temenggor_perak');
  const [selectedDamType, setSelectedDamType] = useState<DamType>('concrete_gravity');
  const [searchQuery, setSearchQuery] = useState('');
  const [regionFilter, setRegionFilter] = useState<'ALL' | 'PENINSULAR' | 'SARAWAK' | 'SABAH'>('ALL');

  const filteredRegions = MALAYSIA_REGIONS.filter((r) => {
    const matchesSearch = 
      r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.state.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.district.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (regionFilter === 'PENINSULAR') {
      return r.state !== 'Sarawak' && r.state !== 'Sabah';
    } else if (regionFilter === 'SARAWAK') {
      return r.state === 'Sarawak';
    } else if (regionFilter === 'SABAH') {
      return r.state === 'Sabah';
    }
    return true;
  });

  const selectedRegion = MALAYSIA_REGIONS.find((r) => r.id === selectedRegionId) || MALAYSIA_REGIONS[0];

  return (
    <div className="fixed inset-0 bg-slate-950 text-slate-100 flex flex-col p-4 z-40 select-none overflow-hidden">
      {/* Top Bar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={() => { soundManager.playClick(); onBack(); }}
            className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-base font-extrabold tracking-wider text-white flex items-center gap-2">
              <Compass className="w-5 h-5 text-cyan-400" />
              <span>MALAYSIA HYDROLOGICAL REGION SELECTION</span>
            </h1>
            <p className="text-xs text-slate-400">Select river basin, catchment topography, and engineering dam type</p>
          </div>
        </div>

        {/* Territory Filter Chips */}
        <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800">
          {(['ALL', 'PENINSULAR', 'SARAWAK', 'SABAH'] as const).map((filter) => (
            <button
              key={filter}
              onClick={() => { soundManager.playClick(); setRegionFilter(filter); }}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                regionFilter === filter
                  ? 'bg-cyan-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
      </div>

      {/* Main Split Layout */}
      <div className="flex-1 flex gap-4 pt-3 overflow-hidden">
        {/* Left Column: Region List & Search */}
        <div className="w-1/2 flex flex-col gap-2 overflow-hidden">
          {/* Search Bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Search by state or district (e.g. Perak, Belaga, Kenyir)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Scrollable Region Cards */}
          <div className="flex-1 overflow-y-auto space-y-2 pr-1">
            {filteredRegions.map((region) => {
              const isSelected = region.id === selectedRegionId;

              return (
                <div
                  key={region.id}
                  onClick={() => {
                    soundManager.playClick();
                    setSelectedRegionId(region.id);
                  }}
                  className={`p-3 rounded-xl border cursor-pointer transition-all active:scale-[0.99] ${
                    isSelected
                      ? 'bg-slate-900 border-cyan-500/80 shadow-lg'
                      : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-1.5 text-xs font-extrabold text-white">
                        <MapPin className={`w-3.5 h-3.5 ${isSelected ? 'text-cyan-400' : 'text-slate-400'}`} />
                        <span>{region.name}</span>
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                        {region.district}, {region.state}
                      </div>
                    </div>
                    <span className="text-[10px] font-mono font-bold bg-slate-800 px-2 py-0.5 rounded text-cyan-300 border border-slate-700">
                      {region.installedCapacityMW} MW
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Selected Region Dossier & Dam Type */}
        <div className="w-1/2 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between overflow-y-auto">
          <div>
            {/* Header */}
            <div className="border-b border-slate-800 pb-3 mb-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono font-bold text-cyan-400">
                  COORDINATES: {selectedRegion.coordinates.lat}°N, {selectedRegion.coordinates.lng}°E
                </span>
                <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded font-bold">
                  PLAYABLE 3D REGION
                </span>
              </div>
              <h2 className="text-base font-extrabold text-white mt-1">{selectedRegion.damName}</h2>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">{selectedRegion.description}</p>
            </div>

            {/* Hydrological Specifications */}
            <div className="grid grid-cols-2 gap-2 mb-4 text-xs font-mono">
              <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 block">CATCHMENT AREA</span>
                <span className="text-slate-100 font-bold">{selectedRegion.catchmentAreaSqKm.toLocaleString()} km²</span>
              </div>
              <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 block">ANNUAL PRECIPITATION</span>
                <span className="text-cyan-300 font-bold">{selectedRegion.annualRainfallMm} mm / yr</span>
              </div>
              <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 block">DESIGN RESERVOIR VOL</span>
                <span className="text-emerald-300 font-bold">{selectedRegion.designCapacityMCM.toLocaleString()} MCM</span>
              </div>
              <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 block">DAM HEIGHT & CREST</span>
                <span className="text-amber-300 font-bold">{selectedRegion.maxHeightM}m H / {selectedRegion.crestLengthM}m L</span>
              </div>
            </div>

            {/* Dam Type Selector */}
            <div className="mb-4">
              <label className="text-xs font-bold text-slate-300 block mb-1.5 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-cyan-400" />
                <span>SELECT STRUCTURAL DAM TYPE</span>
              </label>

              <div className="grid grid-cols-3 gap-2">
                {[
                  { type: 'concrete_gravity', label: 'Concrete Gravity', desc: 'Monolithic mass concrete with internal inspection galleries.' },
                  { type: 'rock_fill', label: 'Rock-Fill Embankment', desc: 'Compacted rockfill with central clay core and concrete face.' },
                  { type: 'earth_fill', label: 'Earth-Fill Embankment', desc: 'Zoned compacted soil embankment with riprap upstream.' },
                ].map((item) => (
                  <button
                    key={item.type}
                    onClick={() => {
                      soundManager.playClick();
                      setSelectedDamType(item.type as DamType);
                    }}
                    className={`p-2 rounded-xl border text-left transition-all ${
                      selectedDamType === item.type
                        ? 'bg-cyan-950/70 border-cyan-400 shadow-md text-white'
                        : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="text-xs font-extrabold">{item.label}</div>
                    <div className="text-[9px] text-slate-400 mt-0.5 line-clamp-2">{item.desc}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Launch Button */}
          <button
            onClick={() => {
              soundManager.playClick();
              onSelectRegion(selectedRegion, selectedDamType);
            }}
            className="w-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold py-3 rounded-xl text-xs flex items-center justify-center gap-2 shadow-xl active:scale-95 transition-all mt-2"
          >
            <span>COMMENCE PROJECT & ENTER 3D WORLD</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
