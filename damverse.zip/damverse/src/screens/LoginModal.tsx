import React, { useState } from 'react';
import { X, Lock, Mail, User, ShieldCheck, ArrowRight, AlertCircle, CheckCircle2 } from 'lucide-react';
import { authManager } from '../lib/auth';
import { soundManager } from '../lib/audio';

interface LoginModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ onClose, onSuccess }) => {
  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [infoMsg, setInfoMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    soundManager.playClick();
    setErrorMsg(null);
    setInfoMsg(null);
    setLoading(true);

    if (mode === 'login') {
      const res = await authManager.signInWithEmail(email, password);
      setLoading(false);
      if (res.success) {
        onSuccess();
        onClose();
      } else {
        setErrorMsg(res.error || 'Failed to sign in. Verify credentials.');
      }
    } else if (mode === 'signup') {
      if (!username.trim()) {
        setLoading(false);
        setErrorMsg('Please choose an engineer callsign / username.');
        return;
      }
      const res = await authManager.signUpWithEmail(email, password, username);
      setLoading(false);
      if (res.success) {
        setInfoMsg('Account created successfully! Check your email if verification was sent, or sign in.');
        setMode('login');
      } else {
        setErrorMsg(res.error || 'Registration failed.');
      }
    } else if (mode === 'forgot') {
      const res = await authManager.resetPassword(email);
      setLoading(false);
      if (res.success) {
        setInfoMsg('Password reset instructions dispatched to your email.');
      } else {
        setErrorMsg(res.error || 'Reset failed.');
      }
    }
  };

  const handleGuest = () => {
    soundManager.playClick();
    authManager.startGuestMode();
    onSuccess();
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 z-50 select-none">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-2xl p-6 text-slate-100 shadow-2xl relative">
        {/* Close Button */}
        <button
          onClick={() => { soundManager.playClick(); onClose(); }}
          className="absolute top-4 right-4 w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-500/50 flex items-center justify-center text-cyan-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white tracking-wide">
              {mode === 'login' ? 'ENGINEER SIGN IN' : mode === 'signup' ? 'REGISTER ACCOUNT' : 'RECOVER ACCESS'}
            </h2>
            <p className="text-xs text-slate-400">Supabase Cloud Authentication & Saves</p>
          </div>
        </div>

        {errorMsg && (
          <div className="mb-4 bg-red-950/60 border border-red-800 text-red-300 text-xs p-3 rounded-xl flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {infoMsg && (
          <div className="mb-4 bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs p-3 rounded-xl flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{infoMsg}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-3">
          {mode === 'signup' && (
            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">CALLSIGN / USERNAME</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  required
                  placeholder="e.g. ChiefEngineer_Azman"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>
          )}

          <div>
            <label className="text-[11px] font-bold text-slate-300 block mb-1">EMAIL ADDRESS</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="email"
                required
                placeholder="engineer@damverse.my"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          {mode !== 'forgot' && (
            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">PASSWORD</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="password"
                  required
                  minLength={6}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all"
          >
            <span>{loading ? 'PROCESSING...' : mode === 'login' ? 'SIGN IN' : mode === 'signup' ? 'REGISTER CALLSIGN' : 'SEND RESET LINK'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Toggles */}
        <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          {mode === 'login' ? (
            <>
              <button
                onClick={() => { soundManager.playClick(); setMode('signup'); setErrorMsg(null); }}
                className="hover:text-cyan-400 underline"
              >
                Create Account
              </button>
              <button
                onClick={() => { soundManager.playClick(); setMode('forgot'); setErrorMsg(null); }}
                className="hover:text-slate-200"
              >
                Forgot Password?
              </button>
            </>
          ) : (
            <button
              onClick={() => { soundManager.playClick(); setMode('login'); setErrorMsg(null); }}
              className="hover:text-cyan-400 underline mx-auto"
            >
              Back to Sign In
            </button>
          )}
        </div>

        {/* Guest Mode Option */}
        <div className="mt-3">
          <button
            onClick={handleGuest}
            className="w-full bg-slate-800 hover:bg-slate-700 text-slate-300 py-2 rounded-xl text-xs font-semibold border border-slate-700 transition-all active:scale-95"
          >
            Play as Guest (Offline Local Saves)
          </button>
        </div>
      </div>
    </div>
  );
};
