-- DAMVERSE Database Schema & Migrations
-- Phase 2 / Section 4

-- 1. Profiles Table
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT NOT NULL,
  avatar_url TEXT,
  level INT DEFAULT 1,
  reputation INT DEFAULT 100,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Game Regions Table (Malaysian hydrological locations)
CREATE TABLE IF NOT EXISTS public.game_regions (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  state TEXT NOT NULL,
  district TEXT NOT NULL,
  dam_name TEXT NOT NULL,
  default_dam_type TEXT DEFAULT 'Concrete Gravity',
  catchment_area_sqkm NUMERIC DEFAULT 1500,
  annual_rainfall_mm NUMERIC DEFAULT 2800,
  normal_inflow_cms NUMERIC DEFAULT 120,
  design_capacity_mcm NUMERIC DEFAULT 3500,
  max_height_m NUMERIC DEFAULT 160,
  crest_length_m NUMERIC DEFAULT 850,
  installed_capacity_mw NUMERIC DEFAULT 400,
  is_playable BOOLEAN DEFAULT TRUE,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Game Saves Table (Player cloud slots)
CREATE TABLE IF NOT EXISTS public.game_saves (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  slot_number INT NOT NULL DEFAULT 1,
  save_name TEXT NOT NULL,
  region_id TEXT NOT NULL REFERENCES public.game_regions(id),
  construction_stage INT NOT NULL DEFAULT 1,
  finances JSONB NOT NULL DEFAULT '{"funds": 25000000, "totalRevenue": 0, "hourlyRate": 35000}'::jsonb,
  reservoir JSONB NOT NULL DEFAULT '{"waterLevel": 120.0, "maxLevel": 160.0, "currentVolumeMCM": 1800, "inflow": 125.0, "spillwayOpening": 0.0, "weather": "clear"}'::jsonb,
  turbines JSONB NOT NULL DEFAULT '[{"id": 1, "active": false, "flow": 0, "outputMW": 0, "efficiency": 0.93}, {"id": 2, "active": false, "flow": 0, "outputMW": 0, "efficiency": 0.93}, {"id": 3, "active": false, "flow": 0, "outputMW": 0, "efficiency": 0.93}, {"id": 4, "active": false, "flow": 0, "outputMW": 0, "efficiency": 0.93}]'::jsonb,
  upgrades JSONB NOT NULL DEFAULT '{"scada": false, "fishLadder": false, "solarFarm": false, "waterTreatment": false, "floodBarrier": false}'::jsonb,
  missions JSONB NOT NULL DEFAULT '{"completed": [], "active": "m_impound_start"}'::jsonb,
  player_pos JSONB DEFAULT '{"x": 0, "y": 142, "z": 10, "inVehicle": false}'::jsonb,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  CONSTRAINT unique_user_slot UNIQUE(user_id, slot_number)
);

-- 4. Dam Projects Table
CREATE TABLE IF NOT EXISTS public.dam_projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  dam_type TEXT NOT NULL,
  state TEXT NOT NULL,
  district TEXT NOT NULL,
  stage INT NOT NULL DEFAULT 1,
  capacity_mw NUMERIC DEFAULT 400,
  status TEXT DEFAULT 'IN_CONSTRUCTION',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Game Settings Table
CREATE TABLE IF NOT EXISTS public.game_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
  graphics_preset TEXT DEFAULT 'HIGH',
  render_scale NUMERIC DEFAULT 1.0,
  shadows_enabled BOOLEAN DEFAULT TRUE,
  post_processing BOOLEAN DEFAULT TRUE,
  master_volume NUMERIC DEFAULT 0.8,
  sfx_volume NUMERIC DEFAULT 0.85,
  ambient_volume NUMERIC DEFAULT 0.75,
  music_volume NUMERIC DEFAULT 0.6,
  camera_sensitivity NUMERIC DEFAULT 1.2,
  invert_y BOOLEAN DEFAULT FALSE,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Game Missions Definition Table
CREATE TABLE IF NOT EXISTS public.game_missions (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  objective TEXT NOT NULL,
  category TEXT NOT NULL,
  reward_rm NUMERIC NOT NULL,
  target_metric TEXT NOT NULL,
  target_value NUMERIC NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Seed Public Malaysian Regions
INSERT INTO public.game_regions (id, name, state, district, dam_name, default_dam_type, catchment_area_sqkm, annual_rainfall_mm, normal_inflow_cms, design_capacity_mcm, max_height_m, crest_length_m, installed_capacity_mw, is_playable, description)
VALUES 
  ('temenggor_perak', 'Temenggor Gorge', 'Perak', 'Hulu Perak', 'Temenggor Hydroelectric Dam', 'Rock-fill with Concrete Spillway', 3420, 2450, 140, 6050, 127, 537, 348, true, 'Located in Hulu Perak along Sungai Perak. Deep tropical canyon, massive reservoir feeding the northern Peninsular grid.'),
  ('kenyir_terengganu', 'Tasik Kenyir Valley', 'Terengganu', 'Hulu Terengganu', 'Sultan Mahmud Dam', 'Rock-fill Embankment', 2600, 3200, 180, 13600, 150, 800, 400, true, 'Malaysia’s largest artificial reservoir surrounded by ancient rainforest. Exceptional rainfall during northeast monsoon.'),
  ('bakun_sarawak', 'Balui Gorge', 'Sarawak', 'Belaga', 'Bakun Hydroelectric Project', 'Concrete-Face Rockfill (CFRD)', 14750, 4100, 1200, 43800, 205, 750, 2400, true, 'Mega-structure deep in central Borneo across the Balui River. Formidable hydraulic head and enormous power generation potential.'),
  ('murum_sarawak', 'Murum River Canyon', 'Sarawak', 'Kapit', 'Murum Dam', 'Roller-Compacted Concrete (RCC)', 2750, 3800, 320, 12000, 141, 473, 944, true, 'High-tech RCC stepped spillway design in dense Sarawak highlands. Supplies clean electricity to industrial corridors.'),
  ('cameron_pahang', 'Ringlet Valley', 'Pahang', 'Cameron Highlands', 'Sultan Abu Bakar Dam', 'Concrete Buttress & Gravity', 183, 2700, 45, 60, 40, 140, 150, true, 'Montane cloud forest valley with high hydraulic drop. Demands rigorous siltation and catchment runoff management.'),
  ('chenderoh_perak', 'Chenderoh Lake', 'Perak', 'Kuala Kangsar', 'Chenderoh Historic Dam', 'Concrete Hollow Arch & Gravity', 6400, 2200, 210, 95, 33, 260, 40, true, 'One of Southeast Asia’s historic hydroelectric marvels on Sungai Perak. Scenic downstream river flats and heritage structures.'),
  ('tenom_sabah', 'Padas River Gorge', 'Sabah', 'Tenom', 'Tenom Pangi Hydroelectric Station', 'Run-of-River Diversion Weir', 1850, 2600, 110, 45, 30, 180, 66, true, 'Turbulent white water gorge in Interior Division Sabah with dedicated intake tunnel.')
ON CONFLICT (id) DO NOTHING;

-- 8. Seed Missions
INSERT INTO public.game_missions (id, title, objective, category, reward_rm, target_metric, target_value)
VALUES
  ('m_diversion_safe', 'River Diversion Mastery', 'Complete the cofferdam and diversion tunnel to dry the dam footprint.', 'construction', 2000000, 'stage', 2),
  ('m_concrete_monolith', 'Mass Pour Phase', 'Complete monolithic block lifts to reach EL 100m.', 'construction', 5000000, 'stage', 4),
  ('m_powerhouse_online', 'Power to the Grid', 'Synchronize Turbine 1 and supply at least 80 MW at 50 Hz.', 'energy', 3500000, 'power_mw', 80),
  ('m_monsoon_flood_gate', 'Monsoon Flood Defense', 'Discharge 450 m³/s through radial spillway gates to prevent reservoir overtopping during torrential storm.', 'hydrology', 4000000, 'spillway_safe', 1),
  ('m_settlement_electrification', 'Township Electrification', 'Connect the downstream Malaysian village and light up 100% of residential quarters.', 'development', 2500000, 'grid_coverage', 100)
ON CONFLICT (id) DO NOTHING;

-- 9. Enable Row Level Security (RLS)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.game_saves ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dam_projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.game_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.game_regions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.game_missions ENABLE ROW LEVEL SECURITY;

-- 10. RLS Policies
-- Profiles: Users can read all public profiles, but only update their own
CREATE POLICY "Public profiles are viewable by everyone" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Users can insert their own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can update their own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- Game Saves: Isolated to authenticated owner
CREATE POLICY "Users manage own game saves" ON public.game_saves FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Dam Projects: Isolated to authenticated owner
CREATE POLICY "Users manage own dam projects" ON public.dam_projects FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Game Settings: Isolated to authenticated owner
CREATE POLICY "Users manage own settings" ON public.game_settings FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Regions & Missions: Publicly readable for gameplay
CREATE POLICY "Game regions are viewable by everyone" ON public.game_regions FOR SELECT USING (true);
CREATE POLICY "Game missions are viewable by everyone" ON public.game_missions FOR SELECT USING (true);
